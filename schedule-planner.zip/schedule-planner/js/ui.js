'use strict';

export function renderTasks(tasks, container) {

    container.innerHTML = '';

    tasks.forEach(task => {

        const taskElement = document.createElement('div');

        taskElement.classList.add('task');

        const now = new Date();
        const deadline = new Date(task.deadline);

        const difference = deadline - now;
        const oneDay = 1000 * 60 * 60 * 24;

        if (difference < 0 && !task.completed) {
            taskElement.classList.add('overdue');
        }
        else if (difference <= oneDay && !task.completed) {
            taskElement.classList.add('warning');
        }

        taskElement.innerHTML = `

            <div class="task-header">

                <div>
                    <div class="task-title ${task.completed ? 'completed' : ''}">
                        ${task.title}
                    </div>

                    <div class="task-date">
                        ${new Date(task.deadline).toLocaleString()}
                    </div>
                </div>

                <div class="checkbox">
                    ${task.completed ? '✖' : ''}
                </div>

            </div>

            <div class="task-description ${task.completed ? 'completed' : ''}">
                ${task.description}
            </div>

            <div class="task-footer">

    <div class="priority">
        ${task.priority}
    </div>

    <button class="delete-btn">
        Удалить
    </button>

</div>
        `;

        const checkbox = taskElement.querySelector('.checkbox');

        const deleteButton = taskElement.querySelector('.delete-btn');

        checkbox.addEventListener('click', () => {

            task.completed = !task.completed;

            renderTasks(tasks, container);

            localStorage.setItem('tasks', JSON.stringify(tasks));
        });
        deleteButton.addEventListener('click', () => {

    const updatedTasks = tasks.filter(
        currentTask => currentTask.id !== task.id
    );

    localStorage.setItem(
        'tasks',
        JSON.stringify(updatedTasks)
    );

    renderTasks(updatedTasks, container);

    tasks.length = 0;
    tasks.push(...updatedTasks);
});

        container.append(taskElement);
    });
}