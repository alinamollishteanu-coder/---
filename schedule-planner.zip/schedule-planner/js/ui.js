'use strict';

export function renderTasks(tasks, container) {

    container.innerHTML = '';

    tasks.forEach(task => {

        const taskElement = document.createElement('div');

        taskElement.classList.add('task');

        const now = new Date();
        const deadline = new Date(task.deadline);

        const difference = deadline - now;
        const oneDay = 1000 * 60 * 60 * 24;

        if (difference < 0 && !task.completed) {
            taskElement.classList.add('overdue');
        }
        else if (difference <= oneDay && !task.completed) {
            taskElement.classList.add('warning');
        }

        taskElement.innerHTML = `

            <div class="task-header">

                <div>
                    <div class="task-title ${task.completed ? 'completed' : ''}">
                        ${task.title}
                    </div>

                    <div class="task-date">
                        ${new Date(task.deadline).toLocaleString()}
                    </div>
                </div>

                <div class="checkbox">
                    ${task.completed ? '✖' : ''}
                </div>

            </div>

            <div class="task-description ${task.completed ? 'completed' : ''}">
                ${task.description}
            </div>

            <div class="priority">
                ${task.priority}
            </div>
        `;

        const checkbox = taskElement.querySelector('.checkbox');

        checkbox.addEventListener('click', () => {

            task.completed = !task.completed;

            renderTasks(tasks, container);

            localStorage.setItem('tasks', JSON.stringify(tasks));
        });

        container.append(taskElement);
    });
}