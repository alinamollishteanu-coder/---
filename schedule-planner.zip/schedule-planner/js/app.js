'use strict';

import { ImportantTask } from './tasks.js';
import { renderTasks } from './ui.js';
import { saveTasks, loadTasks } from './storage.js';

const form = document.getElementById('taskForm');
const titleInput = document.getElementById('title');
const descriptionInput = document.getElementById('description');
const deadlineInput = document.getElementById('deadline');
const priorityInput = document.getElementById('priority');
const tasksContainer = document.getElementById('tasksContainer');
const errorMessage = document.getElementById('errorMessage');
const viewMode = document.getElementById('viewMode');

let tasks = loadTasks();

renderTasks(tasks, tasksContainer);

form.addEventListener('submit', event => {

    event.preventDefault();

    try {

        if (
            !titleInput.value.trim() ||
            !descriptionInput.value.trim() ||
            !deadlineInput.value
        ) {
            throw new Error('Заполните все поля');
        }

        const { value: title } = titleInput;
        const { value: description } = descriptionInput;
        const { value: deadline } = deadlineInput;
        const { value: priority } = priorityInput;

        const task = new ImportantTask(
            title,
            description,
            deadline,
            priority
        );

        tasks.push(task);

        saveTasks(tasks);

        renderTasks(tasks, tasksContainer);

        form.reset();

        errorMessage.textContent = '';

    } catch (error) {

        errorMessage.textContent = error.message;
    }
});

viewMode.addEventListener('change', () => {

    const mode = viewMode.value;

    if (!mode) {
        renderTasks(tasks, tasksContainer);
        return;
    }

    const now = new Date();

    const filteredTasks = tasks.filter(task => {

        const taskDate = new Date(task.deadline);

        if (mode === 'day') {
            return taskDate.toDateString() === now.toDateString();
        }

        if (mode === 'week') {

            const diff =
                (taskDate - now) / (1000 * 60 * 60 * 24);

            return diff <= 7 && diff >= 0;
        }

        if (mode === 'month') {

            return (
                taskDate.getMonth() === now.getMonth() &&
                taskDate.getFullYear() === now.getFullYear()
            );
        }

        if (mode === 'year') {
            return taskDate.getFullYear() === now.getFullYear();
        }
    });

    renderTasks(filteredTasks, tasksContainer);
});