'use strict';

export class Task {

    constructor(title, description, deadline, priority) {

        this.id = Date.now();
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.priority = priority;
        this.completed = false;
    }

    toggleComplete() {
        this.completed = !this.completed;
    }
}

export class ImportantTask extends Task {

    constructor(title, description, deadline, priority, category = 'Основное') {

        super(title, description, deadline, priority);

        this.category = category;
    }
}